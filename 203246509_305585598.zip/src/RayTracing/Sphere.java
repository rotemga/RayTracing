package RayTracing;


public class Sphere extends Object3D{

	private Tuple3D position_center;
	private double radius;
	
	public Sphere(Tuple3D  position_center, double radius, int material_index) {
		super(material_index);
		this.position_center =  position_center;
		this.radius = radius;

	}

	public Tuple3D getPosition() {
		return  position_center;
	}

	public void setPosition(Tuple3D  position_center) {
		this.position_center =  position_center;
	}

	public double getRaduis() {
		return radius;
	}

	public void setRaduis(double raduis) {
		this.radius = raduis;
	}
	
	
	@Override
	public double getIntersection(Ray ray)
	{
	
		Tuple3D direction	=	ray.getDirection(),
				origin		=	ray.getOrigin(),
				subtraction	=	origin.sub(position_center);
	    
		// solving ad^2 +bd +c
	    double 	a= direction.dotFactor(direction),
	    		b= 2*direction.dotFactor(subtraction),
	    		c= subtraction.dotFactor(subtraction)-radius*radius;
	    
	    double delta=b*b-4*a*c;
	    if(delta<0) return -1;
	    
	    
	    double sqrtDelta=Math.sqrt(delta);
	    double solution1=(-b-sqrtDelta)/(2*a);
	    double solution2=(-b+sqrtDelta)/(2*a);
	    
	    return (solution1>0)?solution1:(solution2>0)?solution2:-1;
	}
	
	@Override
	public String toString(){
		return String.format("Sphere : (center:%s,radius:%f)\n", this.position_center,this.radius);
	}

	@Override
	public Tuple3D getNormalAt(Tuple3D point) {
		return point.sub(position_center).normalized();
	}


}	
